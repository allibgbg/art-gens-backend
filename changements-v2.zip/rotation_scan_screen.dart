import 'dart:async';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import '../services/multi_angle_scan.dart';
import '../services/api_client.dart';
import 'package:provider/provider.dart';
import 'finalize_piece_screen.dart';

class RotationScanScreen extends StatefulWidget {
  final String pieceId;
  final String? digitGuess;
  const RotationScanScreen({super.key, required this.pieceId, this.digitGuess});

  @override
  State<RotationScanScreen> createState() => _RotationScanScreenState();
}

class _RotationScanScreenState extends State<RotationScanScreen> {
  CameraController? _cameraController;
  bool _isCameraReady = false;
  bool _scanning = false;
  bool _done = false;
  bool _saving = false;
  double _coverage = 0;
  double _confidence = 0;
  int _framesProcessed = 0;
  double _liveSharpness = 0;
  double _maxSharpness = 0;
  int _calibPct = 0;
  int _skippedBlurry = 0;
  MultiAngleScanner? _scanner;
  String? _error;
  ScanResult? _result;

  @override
  void initState() {
    super.initState();
    _initCamera();
  }

  Future<void> _initCamera() async {
    final cameras = await availableCameras();
    if (cameras.isEmpty) { setState(() => _error = 'Aucune caméra disponible'); return; }
    try {
      final controller = CameraController(cameras.first, ResolutionPreset.medium);
      await controller.initialize();
      if (mounted) {
        setState(() { _cameraController = controller; _isCameraReady = true; _error = null; });
        _startScan();
      }
    } catch (e) { if (mounted) setState(() => _error = 'Erreur caméra: $e'); }
  }

  Future<void> _startScan() async {
    if (_cameraController == null || _scanning) return;
    setState(() { _scanning = true; _done = false; });
    final scanner = MultiAngleScanner(_cameraController!, gridRows: 5, gridCols: 5);
    _scanner = scanner;

    scanner.onProgress = (cov, conf) {
      if (mounted) setState(() { _coverage = cov; _confidence = conf; });
    };
    scanner.onSharpness = (qs, max, calibPct, skipped, processed) {
      if (mounted) setState(() {
        _liveSharpness = qs; _maxSharpness = max; _calibPct = calibPct;
        _skippedBlurry = skipped; _framesProcessed = processed;
      });
    };

    try {
      _result = await scanner.start();
    } catch (_) { _result = null; }

    if (mounted) {
      setState(() { _scanning = false; _done = true; });
      await Future.delayed(const Duration(milliseconds: 600));
      _saveAndNext();
    }
  }

  Future<void> _saveAndNext() async {
    if (_result == null) return;
    setState(() => _saving = true);
    try {
      final api = context.read<ApiClient>();
      await api.patch('/pieces/${widget.pieceId}', body: {
        'color_signature': _result!.spatialSignature,
      });
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => FinalizePieceScreen(
            pieceId: widget.pieceId, digitGuess: widget.digitGuess,
          )),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Erreur: $e')));
      }
    }
  }

  void _retry() {
    setState(() { _result = null; _done = false; });
    _startScan();
  }

  @override
  void dispose() { _cameraController?.dispose(); _scanner?.cancel(); super.dispose(); }

  double get _gaugeValue => _saving ? 1.0 : (_done ? 1.0 : 0.8 + _coverage * 0.2);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Phase 3 — Rotation complète')),
      body: _error != null
          ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(_error!, style: const TextStyle(color: Colors.red)),
              const SizedBox(height: 16),
              ElevatedButton(onPressed: () { setState(() => _error = null); _initCamera(); }, child: const Text('Réessayer')),
            ]))
          : Stack(children: [
              if (_isCameraReady && _cameraController != null) CameraPreview(_cameraController!),
              if (!_isCameraReady) const Center(child: CircularProgressIndicator()),
              Column(children: [
                const Spacer(),
                Container(
                  margin: const EdgeInsets.all(24), padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(16)),
                  child: Column(children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: _gaugeValue, minHeight: 16, backgroundColor: Colors.white24,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          _done || _saving ? Colors.green : Colors.amber),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      _saving ? 'Finalisation... 100%'
                      : _done ? '100% — Rotation terminée !'
                      : 'Rotation : ${(_coverage * 100).toStringAsFixed(0)}%',
                      style: TextStyle(
                        color: _done || _saving ? Colors.greenAccent : Colors.white70,
                        fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    Icon(_saving ? Icons.hourglass_top : (_done ? Icons.check_circle : Icons.threesixty),
                      color: _done || _saving ? Colors.green : Colors.amber, size: 48),
                    const SizedBox(height: 8),
                    Text(
                      _saving ? 'Sauvegarde des motifs...'
                      : _done ? 'Données couleur suffisantes !'
                      : 'Tourne l\'objet sur lui-même\nface à la caméra',
                      style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    if (_scanning) ...[
                      const SizedBox(height: 6),
                      Text('Couverture: ${(_coverage * 100).toStringAsFixed(0)}% | Frames: $_framesProcessed',
                        style: const TextStyle(color: Colors.white70, fontSize: 13)),
                      Text('Netteté: ${_liveSharpness.toStringAsFixed(1)} | Calib: $_calibPct% | Floues: $_skippedBlurry',
                        style: const TextStyle(color: Colors.white54, fontSize: 11)),
                    ],
                    if (_done && !_saving) ...[
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: _retry,
                          icon: const Icon(Icons.refresh),
                          label: const Text('Refaire la rotation'),
                        ),
                      ),
                    ],
                  ]),
                ),
                const SizedBox(height: 32),
              ]),
            ]),
    );
  }
}
