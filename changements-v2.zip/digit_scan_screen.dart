import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:opencv_dart/opencv_dart.dart' as cv;
import '../services/api_client.dart';
import 'package:provider/provider.dart';
import 'rotation_scan_screen.dart';

class DigitScanScreen extends StatefulWidget {
  final String pieceId;
  const DigitScanScreen({super.key, required this.pieceId});

  @override
  State<DigitScanScreen> createState() => _DigitScanScreenState();
}

class _DigitScanScreenState extends State<DigitScanScreen> {
  CameraController? _cameraController;
  bool _isCameraReady = false;
  bool _done = false;
  bool _saving = false;
  String? _error;
  String? _digitGuess;
  double _digitConfidence = 0.0;

  @override
  void initState() {
    super.initState();
    _initCamera();
  }

  Future<void> _initCamera() async {
    final cameras = await availableCameras();
    if (cameras.isEmpty) { setState(() => _error = 'Aucune caméra disponible'); return; }
    try {
      final controller = CameraController(cameras.first, ResolutionPreset.high);
      await controller.initialize();
      if (mounted) {
        setState(() { _cameraController = controller; _isCameraReady = true; _error = null; });
        _captureAndAnalyze();
      }
    } catch (e) { if (mounted) setState(() => _error = 'Erreur caméra: $e'); }
  }

  Future<void> _captureAndAnalyze() async {
    await Future.delayed(const Duration(milliseconds: 500));
    if (!mounted || _cameraController == null) return;
    try {
      final xfile = await _cameraController!.takePicture();
      final bytes = await xfile.readAsBytes();
      _analyzeDigit(bytes);
      if (mounted) setState(() => _done = true);
      await Future.delayed(const Duration(milliseconds: 800));
      _saveAndNext(bytes);
    } catch (e) {
      if (mounted) setState(() => _error = 'Erreur capture: $e');
    }
  }

  void _analyzeDigit(Uint8List jpeg) {
    try {
      final raw = jpeg is Uint8List ? jpeg : Uint8List.fromList(jpeg);
      final img = cv.imdecode(raw, cv.IMREAD_COLOR);
      if (img == null) return;
      final gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY);
      img.dispose();
      final (_, bin) = cv.threshold(gray, 0, 255, cv.THRESH_BINARY_INV + cv.THRESH_OTSU);
      gray.dispose();
      final m = cv.moments(bin, binaryImage: true);
      bin.dispose();
      final nu20 = m.nu20, nu02 = m.nu02, nu11 = m.nu11;
      final nu30 = m.nu30, nu12 = m.nu12, nu21 = m.nu21, nu03 = m.nu03;
      m.dispose();
      double sq(double x) => x * x;
      final hu = <double>[
        nu20 + nu02,
        sq(nu20 - nu02) + 4 * sq(nu11),
        sq(nu30 - 3 * nu12) + sq(3 * nu21 - nu03),
        sq(nu30 + nu12) + sq(nu21 + nu03),
        (nu30 - 3 * nu12) * (nu30 + nu12) * (sq(nu30 + nu12) - 3 * sq(nu21 + nu03))
            + (3 * nu21 - nu03) * (nu21 + nu03) * (3 * sq(nu30 + nu12) - sq(nu21 + nu03)),
        (nu20 - nu02) * (sq(nu30 + nu12) - sq(nu21 + nu03))
            + 4 * nu11 * (nu30 + nu12) * (nu21 + nu03),
        (3 * nu21 - nu03) * (nu30 + nu12) * (sq(nu30 + nu12) - 3 * sq(nu21 + nu03))
            - (nu30 - 3 * nu12) * (nu21 + nu03) * (3 * sq(nu30 + nu12) - sq(nu21 + nu03)),
      ];
      final huLog = hu.map((v) => -v.sign * math.log(v.abs() + 1e-10)).toList();
      const ref2 = [1.85, 3.72, 5.10, 4.85, 9.50, 6.20, 7.30];
      const ref5 = [2.15, 4.30, 5.80, 5.20, 10.40, 6.80, 8.10];
      double dist(List<double> a, List<double> b) { double s = 0; for (int i = 0; i < 7; i++) s += sq(a[i] - b[i]); return math.sqrt(s); }
      final d2 = dist(huLog, ref2), d5 = dist(huLog, ref5);
      _digitConfidence = (1.0 - math.min(d2, d5) / 6.0).clamp(0.0, 1.0);
      _digitGuess = d2 < d5 ? '2' : '5';
    } catch (_) {}
  }

  Future<void> _saveAndNext(Uint8List jpeg) async {
    setState(() => _saving = true);
    try {
      final api = context.read<ApiClient>();
      await api.patch('/pieces/${widget.pieceId}', body: {
        'top_image': base64Encode(jpeg),
      });
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => RotationScanScreen(pieceId: widget.pieceId, digitGuess: _digitGuess)),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Erreur: $e')));
      }
    }
  }

  @override
  void dispose() { _cameraController?.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Phase 2 — Chiffre')),
      body: _error != null
          ? Center(child: Text(_error!, style: const TextStyle(color: Colors.red)))
          : Stack(children: [
              if (_isCameraReady && _cameraController != null) CameraPreview(_cameraController!),
              if (!_isCameraReady) const Center(child: CircularProgressIndicator()),
              Column(children: [
                const Spacer(),
                Container(
                  margin: const EdgeInsets.all(24), padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(16)),
                  child: Column(children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: _saving ? 0.8 : (_done ? 0.8 : 0.6),
                        minHeight: 16, backgroundColor: Colors.white24,
                        valueColor: const AlwaysStoppedAnimation<Color>(Colors.amber),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      _saving ? 'Sauvegarde... 80%'
                      : _done ? '80% — Chiffre $_digitGuess détecté'
                      : 'Détection du chiffre... 60%',
                      style: const TextStyle(color: Colors.amberAccent, fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    Icon(_saving ? Icons.hourglass_top : (_done ? Icons.looks : Icons.camera_alt),
                      color: _done ? Colors.green : Colors.amber, size: 48),
                    const SizedBox(height: 8),
                    Text(
                      _saving ? 'Sauvegarde...'
                      : _done ? 'Chiffre $_digitGuess détecté (${(_digitConfidence * 100).toStringAsFixed(0)}%)'
                      : 'Prise de photo du dessus...',
                      style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ]),
                ),
                const SizedBox(height: 32),
              ]),
            ]),
    );
  }
}
