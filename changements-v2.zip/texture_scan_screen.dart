import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import '../services/texture_extraction.dart';
import '../services/api_client.dart';
import '../providers/auth_provider.dart';
import 'package:provider/provider.dart';
import 'digit_scan_screen.dart';

class TextureScanScreen extends StatefulWidget {
  const TextureScanScreen({super.key});

  @override
  State<TextureScanScreen> createState() => _TextureScanScreenState();
}

class _TextureScanScreenState extends State<TextureScanScreen> {
  CameraController? _cameraController;
  bool _isCameraReady = false;
  bool _capturing = false;
  bool _saving = false;
  double _liveSharpness = 0.0;
  double _maxSharpness = 0.0;
  int _calibPct = 0;
  int _featureCount = 0;
  int _skippedBlurry = 0;
  late TextureExtractor _extractor;
  String? _error;
  int _sensorOrientation = 0;

  List<Map<String, double>>? _displayKps;
  int _lastImageW = 0;
  int _lastImageH = 0;
  int? _stableSinceMs;
  int _stableDurationMs = 0;
  TextureFrame? _capturedFrame;

  List<Map<String, double>> get _bestKps {
    final list = _displayKps;
    if (list == null || list.isEmpty) return [];
    final sorted = List<Map<String, double>>.from(list)
      ..sort((a, b) => (b['response'] ?? 0).compareTo(a['response'] ?? 0));
    return sorted.take(min(7, sorted.length)).toList();
  }

  @override
  void initState() {
    super.initState();
    _extractor = TextureExtractor(nFeatures: 500);
    _initCamera();
  }

  Future<void> _initCamera() async {
    final cameras = await availableCameras();
    if (cameras.isEmpty) {
      setState(() => _error = 'Aucune caméra disponible');
      return;
    }
    try {
      final controller = CameraController(cameras.first, ResolutionPreset.medium);
      await controller.initialize();
      if (mounted) {
        setState(() {
          _cameraController = controller;
          _isCameraReady = true;
          _error = null;
          _sensorOrientation = cameras.first.sensorOrientation;
        });
        _startCapture();
      }
    } catch (e) {
      if (mounted) setState(() => _error = 'Erreur caméra: $e');
    }
  }

  Future<void> _startCapture() async {
    if (_cameraController == null || _capturing) return;
    setState(() {
      _capturing = true;
      _capturedFrame?.dispose();
      _capturedFrame = null;
      _skippedBlurry = 0;
      _stableSinceMs = null;
      _stableDurationMs = 0;
      _displayKps = null;
    });
    try {
      await _cameraController!.startImageStream(_onImage);
    } catch (e) {
      _error = 'Erreur démarrage flux: $e';
      _capturing = false;
    }
  }

  void _onImage(CameraImage image) {
    if (!_capturing) return;
    final rawQs = quickSharpness(image);
    final gate = _extractor.sharpnessGate;
    _lastImageW = image.width;
    _lastImageH = image.height;
    final frame = _extractor.extract(image, logErrors: true);
    if (frame == null) {
      if (mounted) {
        setState(() {
          _liveSharpness = rawQs;
          _maxSharpness = gate.maxSeen;
          _calibPct = gate.calibrationProgress;
          _skippedBlurry++;
        });
      }
      return;
    }
    final kpDisplay = frame.keypoints.map((kp) => <String, double>{
      'x': kp.x, 'y': kp.y, 'response': kp.response,
    }).toList();
    setState(() {
      _liveSharpness = rawQs;
      _maxSharpness = gate.maxSeen;
      _calibPct = gate.calibrationProgress;
      _featureCount = frame.keypoints.length;
      _displayKps = kpDisplay;
    });
    if (frame.keypoints.length >= 7) {
      final now = DateTime.now().millisecondsSinceEpoch;
      if (_stableSinceMs == null) {
        _stableSinceMs = now;
        _capturedFrame?.dispose();
        _capturedFrame = frame;
      } else {
        _capturedFrame?.dispose();
        _capturedFrame = frame;
      }
      setState(() => _stableDurationMs = now - _stableSinceMs!);
      if (_stableDurationMs >= 2000) {
        _saveAndNext();
      }
    } else {
      _stableSinceMs = null;
      _stableDurationMs = 0;
      frame.dispose();
    }
  }

  Future<void> _saveAndNext() async {
    if (_capturedFrame == null) return;
    _capturing = false;
    try { _cameraController?.stopImageStream(); } catch (_) {}
    setState(() => _saving = true);

    try {
      final descMat = _capturedFrame!.descriptors;
      final descData = <List<int>>[];
      for (int i = 0; i < descMat.rows; i++) {
        final row = <int>[];
        for (int j = 0; j < descMat.cols; j++) row.add(descMat.atU8(i, i1: j));
        descData.add(row);
      }
      final kpData = _capturedFrame!.keypoints
          .map((kp) => {'x': kp.x, 'y': kp.y}).toList();
      final api = context.read<ApiClient>();

      final resp = await api.post('/pieces/draft', body: {
        'texture_signature': {
          'descriptors': descData,
          'keypoints': kpData,
          'keypoints_count': _capturedFrame!.keypoints.length,
          'sharpness': _capturedFrame!.sharpness,
        },
      });
      final pieceId = resp['id'] as String;

      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => DigitScanScreen(pieceId: pieceId)),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur sauvegarde: $e')),
        );
        _startCapture();
      }
    }
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    _capturedFrame?.dispose();
    _extractor.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Phase 1 — Texture du fond')),
      body: _error != null
          ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(_error!, style: const TextStyle(color: Colors.red), textAlign: TextAlign.center),
              const SizedBox(height: 16),
              ElevatedButton(onPressed: () { setState(() => _error = null); _initCamera(); }, child: const Text('Réessayer')),
            ]))
          : LayoutBuilder(builder: (context, constraints) => Stack(children: [
              if (_isCameraReady && _cameraController != null)
                CameraPreview(_cameraController!),
              if (!_isCameraReady && _error == null)
                const Center(child: CircularProgressIndicator()),
              if (_displayKps != null && _capturing)
                CustomPaint(
                  size: Size(constraints.maxWidth, constraints.maxHeight),
                  painter: _KeypointPainter(
                    allKps: _displayKps!, bestKps: _bestKps,
                    imageWidth: _lastImageW, imageHeight: _lastImageH,
                    sensorOrientation: _sensorOrientation,
                  ),
                ),
              if (_capturing)
                Center(
                  child: SizedBox(
                    width: MediaQuery.of(context).size.width * 0.7,
                    height: MediaQuery.of(context).size.width * 0.7,
                    child: CustomPaint(painter: _CircleGuidePainter()),
                  ),
                ),
              Column(children: [
                const Spacer(),
                Container(
                  margin: const EdgeInsets.all(24), padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(16)),
                  child: Column(children: [
                    // Gauge globale
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: _saving ? 0.6 : (_stableSinceMs != null ? 0.6 * (_stableDurationMs / 2000).clamp(0.0, 1.0) : 0.0),
                        minHeight: 16, backgroundColor: Colors.white24,
                        valueColor: const AlwaysStoppedAnimation<Color>(Colors.green),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      _saving ? 'Sauvegarde... 60%' : 'Texture : ${(_stableSinceMs != null ? (_stableDurationMs / 20).toStringAsFixed(0) : '0')}%',
                      style: const TextStyle(color: Colors.greenAccent, fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    Icon(_saving ? Icons.hourglass_top : Icons.camera_alt,
                      color: _capturing ? Colors.amber : Colors.white54, size: 48),
                    const SizedBox(height: 8),
                    Text(
                      _saving ? 'Sauvegarde de la cartographie...'
                      : _capturing ? 'Scanne le fond poncé\nMaintiens l\'objet immobile'
                      : 'Préparation...',
                      style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    if (_capturing) ...[
                      const SizedBox(height: 6),
                      Text('Points: $_featureCount détectés, ${_bestKps.length} suivis',
                        style: const TextStyle(color: Colors.white70, fontSize: 13)),
                      if (_stableSinceMs != null) ...[
                        const SizedBox(height: 4),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(4),
                          child: LinearProgressIndicator(
                            value: (_stableDurationMs / 2000).clamp(0.0, 1.0),
                            minHeight: 6, backgroundColor: Colors.white24,
                            valueColor: const AlwaysStoppedAnimation<Color>(Colors.green),
                          ),
                        ),
                        Text('Stabilisation... ${(_stableDurationMs / 20).toStringAsFixed(0)}%',
                          style: const TextStyle(color: Colors.greenAccent, fontSize: 12)),
                      ],
                      Text('Netteté: ${_liveSharpness.toStringAsFixed(1)} | Calib: $_calibPct% | Floues: $_skippedBlurry',
                        style: const TextStyle(color: Colors.white54, fontSize: 11)),
                    ],
                  ]),
                ),
                const SizedBox(height: 32),
              ]),
            ])),
    );
  }
}

class _KeypointPainter extends CustomPainter {
  final List<Map<String, double>> allKps;
  final List<Map<String, double>> bestKps;
  final int imageWidth, imageHeight, sensorOrientation;
  _KeypointPainter({required this.allKps, required this.bestKps, required this.imageWidth, required this.imageHeight, required this.sensorOrientation});

  @override
  void paint(Canvas canvas, Size size) {
    if (allKps.isEmpty) return;
    final bool rotated = sensorOrientation == 90 || sensorOrientation == 270;
    final double scaleX = size.width / (rotated ? imageHeight : imageWidth);
    final double scaleY = size.height / (rotated ? imageWidth : imageHeight);
    final double scale = scaleX < scaleY ? scaleX : scaleY;
    final double dispW = (rotated ? imageHeight : imageWidth) * scale;
    final double dispH = (rotated ? imageWidth : imageHeight) * scale;
    final double offsetX = (size.width - dispW) / 2;
    final double offsetY = (size.height - dispH) / 2;
    final bestSet = bestKps.map((b) => '${(b['x']! * 10).round()},${(b['y']! * 10).round()}').toSet();

    for (final kp in allKps) {
      double px, py;
      if (sensorOrientation == 90) { px = kp['y']! * scale + offsetX; py = (imageWidth - kp['x']!) * scale + offsetY; }
      else if (sensorOrientation == 270) { px = (imageHeight - kp['y']!) * scale + offsetX; py = kp['x']! * scale + offsetY; }
      else if (sensorOrientation == 180) { px = (imageWidth - kp['x']!) * scale + offsetX; py = (imageHeight - kp['y']!) * scale + offsetY; }
      else { px = kp['x']! * scale + offsetX; py = kp['y']! * scale + offsetY; }
      final isBest = bestSet.contains('${(kp['x']! * 10).round()},${(kp['y']! * 10).round()}');
      canvas.drawCircle(Offset(px, py), isBest ? 6.0 : 3.0, Paint()..color = isBest ? Colors.red : Colors.white.withOpacity(0.5)..style = PaintingStyle.fill);
      if (isBest) canvas.drawCircle(Offset(px, py), 9.0, Paint()..color = Colors.red.withOpacity(0.5)..style = PaintingStyle.stroke..strokeWidth = 2.5);
    }
  }
  @override bool shouldRepaint(covariant _KeypointPainter oldDelegate) => true;
}

class _CircleGuidePainter extends CustomPainter {
  const _CircleGuidePainter();
  @override
  void paint(Canvas canvas, Size size) {
    final double cx = size.width / 2, cy = size.height / 2, radius = (cx < cy ? cx : cy) * 0.85;
    final paint = Paint()..color = Colors.white38..style = PaintingStyle.stroke..strokeWidth = 2.5;
    canvas.drawCircle(Offset(cx, cy), radius, paint);
    final tickPaint = Paint()..color = Colors.white24..style = PaintingStyle.stroke..strokeWidth = 1;
    for (final angle in [0.0, 90.0, 180.0, 270.0]) {
      final rad = angle * (3.14159 / 180.0);
      final dx = radius * cos(rad), dy = radius * sin(rad);
      canvas.drawLine(Offset(cx + dx * 0.9, cy + dy * 0.9), Offset(cx + dx * 1.1, cy + dy * 1.1), tickPaint);
    }
  }
  @override bool shouldRepaint(covariant _CircleGuidePainter oldDelegate) => false;
}
