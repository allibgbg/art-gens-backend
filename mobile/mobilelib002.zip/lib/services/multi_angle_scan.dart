import 'dart:async';
import 'package:camera/camera.dart';
import 'color_extraction.dart';
import 'texture_extraction.dart';

typedef ScanProgressCallback = void Function(double coverage, double confidence);

/// qs = valeur quickSharpness, max = meilleure netteté vue,
/// calib = progression calibration 0-100, skipped = rejetées, total = traitées
typedef ScanSharpnessCallback = void Function(
    double qs, double max, int calibPct, int skipped, int total);

class ScanResult {
  final Map<String, dynamic> spatialSignature;
  final double confidence;
  final int framesProcessed;

  ScanResult(this.spatialSignature, this.confidence, this.framesProcessed);
}

class MultiAngleScanner {
  final CameraController _camera;
  bool _running = false;
  Timer? _timeoutTimer;
  int _frameCount = 0;
  int _skippedBlurry = 0;
  final CoverageTracker _tracker;
  final AdaptiveSharpnessGate _sharpnessGate = AdaptiveSharpnessGate();

  ScanProgressCallback? onProgress;
  ScanSharpnessCallback? onSharpness;

  MultiAngleScanner(this._camera, {int gridRows = 4, int gridCols = 4})
      : _tracker = CoverageTracker(gridRows, gridCols);

  bool get running => _running;
  double get coverage => _tracker.coverage;
  double get confidence => _tracker.confidence;
  int get framesProcessed => _frameCount;
  int get skippedBlurry => _skippedBlurry;
  bool get isComplete => _tracker.isStable && confidence >= 0.6;

  Future<ScanResult> start({Duration timeout = const Duration(seconds: 30)}) async {
    _running = true;
    _tracker.reset();
    _sharpnessGate.reset();
    _frameCount = 0;
    _skippedBlurry = 0;

    final completer = Completer<ScanResult>();

    _timeoutTimer = Timer(timeout, () {
      _stop();
      if (!completer.isCompleted) {
        completer.complete(_buildResult());
      }
    });

    try {
      await _camera.startImageStream(_onImage);
    } catch (e) {
      _stop();
      throw Exception('Erreur démarrage flux caméra: $e');
    }

    _camera.addListener(() {
      if (!_camera.value.isStreamingImages && _running) {
        _stop();
        if (!completer.isCompleted) {
          completer.complete(_buildResult());
        }
      }
    });

    return completer.future;
  }

  void _onImage(CameraImage image) {
    if (!_running) return;

    final qs = quickSharpness(image);
    if (!_sharpnessGate.isSharp(qs)) {
      _skippedBlurry++;
      onSharpness?.call(qs, _sharpnessGate.maxSeen,
          _sharpnessGate.calibrationProgress, _skippedBlurry, _frameCount);
      return;
    }

    _frameCount++;
    final sig = SpatialSignature.extract(image);
    final cov = _tracker.addFrame(sig);
    onSharpness?.call(qs, _sharpnessGate.maxSeen,
        _sharpnessGate.calibrationProgress, _skippedBlurry, _frameCount);
    onProgress?.call(cov, _tracker.confidence);
  }

  void _stop() {
    _running = false;
    _timeoutTimer?.cancel();
    try {
      _camera.stopImageStream();
    } catch (_) {}
  }

  ScanResult _buildResult() {
    return ScanResult(
      _tracker.toSignatureJson(),
      _tracker.confidence,
      _frameCount,
    );
  }

  void cancel() {
    _stop();
  }
}
