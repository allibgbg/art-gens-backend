import 'dart:math';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import '../services/texture_extraction.dart';
import '../services/api_client.dart';
import '../providers/auth_provider.dart';
import '../providers/pieces_provider.dart';
import 'package:provider/provider.dart';

/// Phase 2 : scan du fond poncé pour extraction de texture.
/// Reçoit la signature couleur via [colorSignature] (optionnel, pré-tri).
class BottomScanScreen extends StatefulWidget {
  final Map<String, dynamic>? colorSignature;

  const BottomScanScreen({super.key, this.colorSignature});

  @override
  State<BottomScanScreen> createState() => _BottomScanScreenState();
}

class _BottomScanScreenState extends State<BottomScanScreen> {
  CameraController? _cameraController;
  bool _isCameraReady = false;
  bool _capturing = false;
  bool _done = false;
  bool _saving = false;
  double _liveSharpness = 0.0;
  int _featureCount = 0;
  TextureFrame? _capturedFrame;
  late TextureExtractor _extractor;
  String? _error;

  @override
  void initState() {
    super.initState();
    _extractor = TextureExtractor(nFeatures: 500);
    _initCamera();
  }

  Future<void> _initCamera() async {
    final cameras = await availableCameras();
    if (cameras.isEmpty) {
      setState(() => _error = 'Aucune caméra disponible');
      return;
    }
    final controller = CameraController(cameras.first, ResolutionPreset.medium);
    await controller.initialize();
    if (mounted) {
      setState(() {
        _cameraController = controller;
        _isCameraReady = true;
      });
    }
  }

  Future<void> _startCapture() async {
    if (_cameraController == null || _capturing) return;
    setState(() {
      _capturing = true;
      _done = false;
      _capturedFrame?.dispose();
      _capturedFrame = null;
    });

    try {
      await _cameraController!.startImageStream(_onImage);
    } catch (e) {
      _error = 'Erreur démarrage flux: $e';
      _capturing = false;
    }
  }

  void _onImage(CameraImage image) {
    if (!_capturing) return;

    final frame = _extractor.extract(image, logErrors: true);

    if (frame == null) {
      if (mounted) {
        setState(() => _liveSharpness = 0.0);
      }
      return;
    }

    setState(() {
      _liveSharpness = frame.sharpness;
      _featureCount = frame.keypoints.length;
    });

    final isSharp = frame.sharpness >= kMinQuickSharpness;
    final hasFeatures = frame.keypoints.length >= 30;

    if (isSharp && hasFeatures) {
      _capturing = false;
      try {
        _cameraController?.stopImageStream();
      } catch (_) {}
      if (mounted) {
        setState(() {
          _capturedFrame = frame;
          _done = true;
        });
      }
    } else {
      frame.dispose();
    }
  }

  Future<void> _validate() async {
    if (_capturedFrame == null) return;
    setState(() => _saving = true);

    final api = context.read<ApiClient>();
    final user = context.read<AuthProvider>().user;

    try {
      // Convertir les descripteurs (binaires uint8) en liste pour l'envoi
      final descMat = _capturedFrame!.descriptors;
      final descRows = descMat.rows;
      final descCols = descMat.cols;
      final descData = <List<int>>[];
      for (int i = 0; i < descRows; i++) {
        final row = <int>[];
        for (int j = 0; j < descCols; j++) {
          row.add(descMat.atU8(i, i1: j));
        }
        descData.add(row);
      }

      final body = {
        'display_number': '${user?.pseudo.toUpperCase() ?? 'ART'}-${DateTime.now().millisecondsSinceEpoch}',
        'series_value': 1,
        'reference_pinceaux_value': 100,
        'color_primary': 'multicolore',
        'color_secondary': null,
        'color_signature': widget.colorSignature,
        'texture_signature': {
          'descriptors': descData,
          'keypoints_count': _capturedFrame!.keypoints.length,
          'sharpness': _capturedFrame!.sharpness,
        },
        'material_notes': null,
        'artist_note': 'Scan complet (dessus + fond poncé)',
      };

      await api.post('/pieces/', body: body);
      await context.read<PiecesProvider>().loadMyPieces();

      if (mounted) {
        setState(() => _saving = false);
        Navigator.pushReplacementNamed(context, '/home');
      }
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur: $e')),
        );
      }
    }
  }

  void _retake() {
    _capturedFrame?.dispose();
    setState(() {
      _done = false;
      _capturedFrame = null;
      _featureCount = 0;
      _liveSharpness = 0.0;
    });
    _startCapture();
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    _capturedFrame?.dispose();
    _extractor.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _error != null
          ? Center(
              child: Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 18)))
          : Stack(
              children: [
                if (_isCameraReady && _cameraController != null)
                  CameraPreview(_cameraController!),
                if (!_isCameraReady && _error == null)
                  const Center(child: CircularProgressIndicator()),

                // Guide circulaire pour le fond
                if (!_done && _capturing)
                  Center(
                    child: SizedBox(
                      width: MediaQuery.of(context).size.width * 0.7,
                      height: MediaQuery.of(context).size.width * 0.7,
                      child: CustomPaint(
                        painter: _CircleGuidePainter(),
                      ),
                    ),
                  ),

                // Overlay
                Column(
                  children: [
                    const Spacer(),
                    Container(
                      margin: const EdgeInsets.all(24),
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        children: [
                          Icon(
                            _done ? Icons.check_circle : Icons.camera_alt,
                            color: _done
                                ? Colors.green
                                : _capturing
                                    ? Colors.amber
                                    : Colors.white54,
                            size: 48,
                          ),
                          const SizedBox(height: 12),
                          Text(
                            _saving
                                ? 'Enregistrement...'
                                : _done
                                    ? 'Fond scanné !'
                                    : _capturing
                                        ? 'Maintiens l\'objet immobile\nface à la caméra'
                                        : 'Scanne le fond poncé',
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          if (_capturing) ...[
                            _sharpnessIndicator(),
                            Text(
                              'Netteté: ${_liveSharpness.toStringAsFixed(1)} | Features: $_featureCount',
                              style: const TextStyle(color: Colors.white70, fontSize: 14),
                            ),
                            const SizedBox(height: 8),
                            if (_featureCount > 0)
                              LinearProgressIndicator(
                                value: (_featureCount / 300).clamp(0.0, 1.0),
                                backgroundColor: Colors.white24,
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  _featureCount >= 30 ? Colors.green : Colors.amber,
                                ),
                              ),
                          ],
                          if (_done) ...[
                            const SizedBox(height: 8),
                            Text(
                              'Features: $_featureCount | Netteté: ${_capturedFrame?.sharpness.toStringAsFixed(1) ?? '-'}',
                              style: const TextStyle(color: Colors.white70, fontSize: 14),
                            ),
                          ],
                          const SizedBox(height: 16),
                          if (!_capturing && !_done && _error == null)
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton.icon(
                                onPressed: _startCapture,
                                icon: const Icon(Icons.camera_alt),
                                label: const Text('Scanner le fond'),
                                style: ElevatedButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(vertical: 14),
                                ),
                              ),
                            ),
                          if (_done && !_saving)
                            Row(
                              children: [
                                Expanded(
                                  child: OutlinedButton.icon(
                                    onPressed: _retake,
                                    icon: const Icon(Icons.refresh),
                                    label: const Text('Rescanner'),
                                    style: OutlinedButton.styleFrom(
                                      foregroundColor: Colors.white,
                                      side: const BorderSide(color: Colors.white38),
                                      padding: const EdgeInsets.symmetric(vertical: 12),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: ElevatedButton.icon(
                                    onPressed: _validate,
                                    icon: const Icon(Icons.check),
                                    label: const Text('Valider'),
                                    style: ElevatedButton.styleFrom(
                                      padding: const EdgeInsets.symmetric(vertical: 12),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          if (_saving)
                            const SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 32),
                  ],
                ),
              ],
            ),
    );
  }

  Widget _sharpnessIndicator() {
    final val = (_liveSharpness / 200.0).clamp(0.0, 1.0);
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(
            value: val,
            minHeight: 12,
            backgroundColor: Colors.white24,
            valueColor: AlwaysStoppedAnimation<Color>(
              _liveSharpness >= kMinQuickSharpness ? Colors.green : Colors.red,
            ),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          'Netteté: ${_liveSharpness.toStringAsFixed(1)}',
          style: TextStyle(
            color: _liveSharpness >= kMinQuickSharpness ? Colors.greenAccent : Colors.redAccent,
            fontSize: 14,
          ),
        ),
      ],
    );
  }
}

class _CircleGuidePainter extends CustomPainter {
  const _CircleGuidePainter();

  @override
  void paint(Canvas canvas, Size size) {
    final double cx = size.width / 2;
    final double cy = size.height / 2;
    final double radius = (cx < cy ? cx : cy) * 0.85;

    final paint = Paint()
      ..color = Colors.white38
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5;
    canvas.drawCircle(Offset(cx, cy), radius, paint);

    final tickPaint = Paint()
      ..color = Colors.white24
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    for (final angle in [0.0, 90.0, 180.0, 270.0]) {
      final rad = angle * (3.14159 / 180.0);
      final dx = radius * cos(rad);
      final dy = radius * sin(rad);
      final inner = Offset(cx + dx * 0.9, cy + dy * 0.9);
      final outer = Offset(cx + dx * 1.1, cy + dy * 1.1);
      canvas.drawLine(inner, outer, tickPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _CircleGuidePainter oldDelegate) => false;
}
