import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'dart:async';
import '../services/multi_angle_scan.dart';
import 'bottom_scan_screen.dart';

class FirstScanScreen extends StatefulWidget {
  const FirstScanScreen({super.key});

  @override
  State<FirstScanScreen> createState() => _FirstScanScreenState();
}

class _FirstScanScreenState extends State<FirstScanScreen>
    with SingleTickerProviderStateMixin {
  CameraController? _cameraController;
  bool _isCameraReady = false;
  bool _scanning = false;
  bool _done = false;
  MultiAngleScanner? _scanner;
  double _confidence = 0;
  ScanResult? _result;
  late AnimationController _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseAnim = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
    _initCamera();
  }

  Future<void> _initCamera() async {
    final cameras = await availableCameras();
    if (cameras.isEmpty) return;
    final controller = CameraController(cameras.first, ResolutionPreset.medium);
    await controller.initialize();
    if (mounted) {
      setState(() {
        _cameraController = controller;
        _isCameraReady = true;
      });
    }
  }

  Future<void> _startScan() async {
    if (_cameraController == null || _scanning) return;
    setState(() {
      _scanning = true;
      _confidence = 0;
    });

    final scanner = MultiAngleScanner(_cameraController!);
    _scanner = scanner;

    scanner.onProgress = (cov, conf) {
      if (mounted) {
        setState(() {
          _confidence = conf;
        });
      }
    };

    try {
      _result = await scanner.start();
    } catch (_) {
      _result = null;
    }

    if (mounted) {
      setState(() {
        _scanning = false;
        _done = true;
      });
    }
  }

  void _validate() async {
    if (_result == null) return;

    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => BottomScanScreen(colorSignature: _result!.spatialSignature),
        ),
      );
    }
  }

  void _resetScan() {
    _scanner?.cancel();
    setState(() {
      _result = null;
      _confidence = 0;
    });
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    _scanner?.cancel();
    _pulseAnim.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final showValidate = _done && _result != null;

    return Scaffold(
      body: Stack(
        children: [
          // Caméra preview
          if (_isCameraReady && _cameraController != null)
            CameraPreview(_cameraController!)
          else
            const Center(child: CircularProgressIndicator()),

          // Guide overlay (ovale coupé)
          if (!_done)
            Center(
              child: SizedBox(
                width: MediaQuery.of(context).size.width * 0.7,
                height: MediaQuery.of(context).size.width * 0.7,
                child: CustomPaint(
                  painter: _GuidePainter(),
                ),
              ),
            ),

          // Overlay
          Column(
            children: [
              const Spacer(),
              // Panneau d'info
              Container(
                margin: const EdgeInsets.all(24),
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  children: [
                    // Icône
                    AnimatedBuilder(
                      animation: _pulseAnim,
                      builder: (_, child) => Transform.rotate(
                        angle: _scanning ? _pulseAnim.value * 0.5 : 0,
                        child: child,
                      ),
                      child: Icon(
                        _done ? Icons.check_circle : Icons.auto_awesome,
                        color: showValidate
                            ? Colors.green
                            : _scanning
                                ? Colors.amber
                                : Colors.white54,
                        size: 48,
                      ),
                    ),
                    const SizedBox(height: 12),
                    // Texte
                    Text(
                      _done
                          ? 'Dessus scanné !\nRetourne l\'objet pour scanner le fond'
                          : _scanning
                              ? 'Tourne l\'objet devant la caméra'
                              : 'Scanne le dessus de l\'objet',
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    // Jauge de couverture
                    if (_scanning || _done) ...[
                      const SizedBox(height: 8),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: LinearProgressIndicator(
                          value: _confidence.clamp(0.0, 1.0),
                          minHeight: 12,
                          backgroundColor: Colors.white24,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            _confidence >= 0.8
                                ? Colors.green
                                : _confidence >= 0.5
                                    ? Colors.amber
                                    : Colors.orange,
                          ),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Couverture : ${(_confidence * 100).toStringAsFixed(0)}%',
                        style: const TextStyle(color: Colors.white70, fontSize: 14),
                      ),
                    ],
                    const SizedBox(height: 16),
                    // Boutons
                    if (!_scanning && !_done)
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: _startScan,
                          icon: const Icon(Icons.camera_alt),
                          label: const Text('Commencer le scan'),
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                        ),
                      ),
                    if (showValidate)
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _resetScan,
                              icon: const Icon(Icons.refresh),
                              label: const Text('Rescanner'),
                              style: OutlinedButton.styleFrom(
                                foregroundColor: Colors.white,
                                side: const BorderSide(color: Colors.white38),
                                padding: const EdgeInsets.symmetric(vertical: 12),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: _validate,
                              icon: const Icon(Icons.check),
                              label: const Text('Valider'),
                              style: ElevatedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(vertical: 12),
                              ),
                            ),
                          ),
                        ],
                      ),

                  ],
                ),
              ),
              const SizedBox(height: 32),
            ],
          ),
        ],
      ),
    );
  }
}

class _GuidePainter extends CustomPainter {
  const _GuidePainter();

  @override
  void paint(Canvas canvas, Size size) {
    final double w = size.width;
    final double h = size.height;
    final double cutRatio = 0.85;
    final double cutY = h * cutRatio;
    final double radius = w * 0.45;

    final guidePaint = Paint()
      ..color = Colors.white38
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5;
    final rrect = RRect.fromRectAndCorners(
      Rect.fromLTWH(0, 0, w, cutY),
      topLeft: Radius.circular(radius),
      topRight: Radius.circular(radius),
    );
    canvas.drawRRect(rrect, guidePaint);
    canvas.drawLine(Offset(0, cutY), Offset(w, cutY), guidePaint);
  }

  @override
  bool shouldRepaint(covariant _GuidePainter oldDelegate) => false;
}
