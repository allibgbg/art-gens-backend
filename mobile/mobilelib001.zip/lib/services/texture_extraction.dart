import 'dart:typed_data';
import 'package:camera/camera.dart';
import 'package:opencv_dart/opencv_dart.dart' as cv;

/// Seuil de netteté rapide (métrique simplifiée sur pixels bruts, pas OpenCV).
/// À calibrer empiriquement.
const double kMinQuickSharpness = 12.0;

/// Mesure rapide de netteté directement sur les bytes Y bruts, sans OpenCV.
/// Calcule la somme des différences absolues horizontales sur un sous-échantillon.
/// Retourne la valeur moyenne de différence (plus = plus net).
/// Ne crée aucune Mat, aucun appel FFI — utilisable à chaque frame.
double quickSharpness(CameraImage image) {
  try {
    final plane = image.planes[0];
    final bytes = plane.bytes;
    final w = image.width;
    final h = image.height;
    final stride = plane.bytesPerRow;
    const step = 4; // sous-échantillonnage 4× pour rester léger

    int sum = 0;
    int count = 0;

    for (int r = 0; r < h; r += step) {
      final rowStart = r * stride;
      for (int c = 0; c < w - 1; c += step) {
        final diff = (bytes[rowStart + c] - bytes[rowStart + c + 1]).abs();
        sum += diff;
        count++;
      }
    }

    if (count == 0) return 0.0;
    return sum / count;
  } catch (_) {
    return 0.0;
  }
}

/// Convertit le plan Y (luma) d'une image caméra en Mat CV_8UC1,
/// en gérant correctement le stride (bytesPerRow) si différent de width.
cv.Mat? yPlaneToGrayMat(CameraImage image, {bool logErrors = false}) {
  try {
    final plane = image.planes[0];
    final h = image.height;
    final w = image.width;
    final stride = plane.bytesPerRow;

    if (stride == w) {
      return cv.Mat.fromList(h, w, cv.MatType.CV_8UC1, plane.bytes.toList());
    }

    // stride != width : copier ligne par ligne en ignorant le padding
    final packed = Uint8List(h * w);
    for (int row = 0; row < h; row++) {
      final srcStart = row * stride;
      final dstStart = row * w;
      for (int col = 0; col < w; col++) {
        packed[dstStart + col] = plane.bytes[srcStart + col];
      }
    }
    return cv.Mat.fromList(h, w, cv.MatType.CV_8UC1, packed.toList());
  } catch (e) {
    if (logErrors) {
      // ignore: avoid_print
      print('[yPlaneToGrayMat] Erreur: $e');
    }
    return null;
  }
}

class TextureFrame {
  final double sharpness;
  final cv.Mat descriptors;
  final List<cv.KeyPoint> keypoints;

  TextureFrame(this.sharpness, this.descriptors, this.keypoints);

  void dispose() {
    descriptors.dispose();
  }
}

/// Extracteur de features avec ORB réutilisable.
/// La netteté est vérifiée en continu (toutes les frames) en Dart pur.
/// L'extraction ORB (lourde) n'est déclenchée que sur les frames nettes.
class TextureExtractor {
  final cv.ORB _orb;
  final cv.Mat _mask = cv.Mat.empty();

  TextureExtractor({int nFeatures = 500})
      : _orb = cv.ORB.create(
          nFeatures: nFeatures,
          scaleFactor: 1.2,
          nLevels: 8,
          edgeThreshold: 31,
          firstLevel: 0,
          WTA_K: 2,
          scoreType: cv.ORBScoreType.FAST_SCORE,
          patchSize: 31,
          fastThreshold: 20,
        );

  /// Vérifie la netteté rapidement (Dart pur, toutes les frames).
  /// Si nette, déclenche la conversion + extraction ORB.
  /// Retourne null si floue ou erreur.
  TextureFrame? extract(CameraImage image, {bool logErrors = false}) {
    // Étape 1 : netteté rapide, sans OpenCV, sur toutes les frames
    final qs = quickSharpness(image);
    if (qs < kMinQuickSharpness) return null;

    // Étape 2 : seulement si nette → conversion OpenCV + ORB
    final grayMat = yPlaneToGrayMat(image, logErrors: logErrors);
    if (grayMat == null) return null;

    try {
      final (keypoints, descriptors) = _orb.detectAndCompute(grayMat, _mask);
      grayMat.dispose();
      return TextureFrame(qs, descriptors, keypoints.toList());
    } catch (e) {
      if (logErrors) {
        // ignore: avoid_print
        print('[TextureExtractor] Erreur detectAndCompute: $e');
      }
      grayMat.dispose();
      return null;
    }
  }

  void dispose() {
    _orb.dispose();
    _mask.dispose();
  }
}

enum FeatureExtractor { orb }
