import 'dart:async';
import 'package:camera/camera.dart';
import 'color_extraction.dart';
import 'texture_extraction.dart';

typedef ScanProgressCallback = void Function(double coverage, double confidence);

class ScanResult {
  final Map<String, dynamic> spatialSignature;
  final double confidence;
  final int framesProcessed;

  ScanResult(this.spatialSignature, this.confidence, this.framesProcessed);
}

class MultiAngleScanner {
  final CameraController _camera;
  bool _running = false;
  Timer? _timeoutTimer;
  int _frameCount = 0;
  int _skippedBlurry = 0;
  final CoverageTracker _tracker;

  ScanProgressCallback? onProgress;

  MultiAngleScanner(this._camera, {int gridRows = 4, int gridCols = 4})
      : _tracker = CoverageTracker(gridRows, gridCols);

  bool get running => _running;
  double get coverage => _tracker.coverage;
  double get confidence => _tracker.confidence;
  int get framesProcessed => _frameCount;
  int get skippedBlurry => _skippedBlurry;
  bool get isComplete => _tracker.isStable && confidence >= 0.6;

  Future<ScanResult> start({Duration timeout = const Duration(seconds: 30)}) async {
    _running = true;
    _tracker.reset();
    _frameCount = 0;
    _skippedBlurry = 0;

    final completer = Completer<ScanResult>();

    _timeoutTimer = Timer(timeout, () {
      _stop();
      if (!completer.isCompleted) {
        completer.complete(_buildResult());
      }
    });

    try {
      await _camera.startImageStream(_onImage);
    } catch (e) {
      _stop();
      throw Exception('Erreur démarrage flux caméra: $e');
    }

    _camera.addListener(() {
      if (!_camera.value.isStreamingImages && _running) {
        _stop();
        if (!completer.isCompleted) {
          completer.complete(_buildResult());
        }
      }
    });

    return completer.future;
  }

  void _onImage(CameraImage image) {
    if (!_running) return;

    // Netteté rapide (Dart pur, toutes les frames) — ignorer les floues
    if (quickSharpness(image) < kMinQuickSharpness) {
      _skippedBlurry++;
      return;
    }

    _frameCount++;
    final sig = SpatialSignature.extract(image);
    final cov = _tracker.addFrame(sig);
    onProgress?.call(cov, _tracker.confidence);
  }

  void _stop() {
    _running = false;
    _timeoutTimer?.cancel();
    try {
      _camera.stopImageStream();
    } catch (_) {}
  }

  ScanResult _buildResult() {
    return ScanResult(
      _tracker.toSignatureJson(),
      _tracker.confidence,
      _frameCount,
    );
  }

  void cancel() {
    _stop();
  }
}
